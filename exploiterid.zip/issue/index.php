<?php 
	
	header("Location: ../index");

 ?>