Diketahui Untuk Database -- 

- Membuat Nama Database = expoiter_id
- Import File expoiter_id ke database expoiterid


-- HTACCESS HALAMAN ADMIN --

- set .htaccess di halaman admin arahkan ke file passwd sesuai letaknya


-- Captcha --

Ubah domain chaptca

